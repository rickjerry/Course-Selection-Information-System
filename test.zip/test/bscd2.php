<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "Good Job! 資料庫連線成功 <br>";
	
	$student_id=$_POST['student_id1'];
	
	$student_name=$_POST['student_name1'];

	$department_code=$_POST['department_code'];
	
    $sqlDelete = "DELETE FROM 學生資料表 
	WHERE 學號 = ? AND 姓名 = ? AND 系碼=?";

	$link->query('SET NAMES utf8');
	
	$record=$link->prepare($sqlDelete);	
	$record -> execute(array($student_id,$student_name,$department_code));

	require 'base.php';

 

}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>