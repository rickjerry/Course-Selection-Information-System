<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";#192.168.43.91

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


	
$student_course=$_POST['student_course'];
	
$course_name=$_POST['course_name'];
	
$department_id=$_POST['credit'];

$teacher_name=$_POST['teacher_name'];

	$sql = "INSERT INTO 課程資料表 VALUES (?, ?, ?, ?)";
	$link->query('SET NAMES utf8');
	
$record=$link->prepare($sql);	
$record -> execute(array($student_course,$course_name,$department_id,$teacher_name));
	
 

	echo "<br>" . "資料新增成功";

	require 'base.php';
}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>