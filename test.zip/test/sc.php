<?php 
// 建立資料庫連接
$servername = "127.0.0.1";
$username = "root";
$password = "yuan1205";
$dbname = "school";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 獲取學生資料
    $sql = "SELECT 課號, 課名,學分數,教師 FROM 課程資料表";
    $courses = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    echo "連線失敗：" . $e->getMessage();
}
?>


<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>

<form method="post">
<br>
Username: <input type="text" name="username">
Password: <input type="password" name="password">
<br>
<br>
<style>

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid black;
            padding: 8px 12px;
            text-align: center;
        }

        table th {
            background-color: #f0e68c;
            color: black;
        }

        table tr:nth-child(even) {
            background-color: #fafad2;
        }
    </style>
	
<table border='1'>
        <tr>
            <th>課號</th>
            <th>課名</th>
            <th>學分數</th>
			<th>教師</th>
        </tr>
<?php foreach ($courses as $course): ?>
        <tr>
            <td><?php echo $course['課號']; ?></td>
            <td><?php echo $course['課名']; ?></td>
            <td><?php echo $course['學分數']; ?></td>
			<td><?php echo $course['教師']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>		

<p>加選:</p>
學號：<input type="text" name="student_id">
課號：<input type="text" name="student_course">

<br>
<input type="submit" value="加選" formaction="bsc.php">
<br>

<p>退選:</p>
學號：<input type="text" name="student_id1">
課號：<input type="text" name="student_course1">
<br>
<input type="submit" value="退選" formaction="bscd.php">
<br>
<?php include 'base.php'; ?>
</form>
</body>
</html>
