<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


	
$student_id=$_POST['student_id'];
	
$student_course=$_POST['student_course'];
$sql_check = "SELECT * FROM 選課紀錄表 WHERE 學號 = ? AND 課號 = ?";
	$stmt_check = $link->prepare($sql_check);
	$stmt_check->execute(array($student_id, $student_course));
	
	if($stmt_check->rowCount() > 0){
		echo "<br>" . "資料已存在，未進行新增";
	} else {
		$sql_insert = "INSERT INTO 選課紀錄表 VALUES (?, ?)";
		$link->query('SET NAMES utf8');
		
		$record=$link->prepare($sql_insert);	
		$record -> execute(array($student_id,$student_course));
		
		echo "<br>" . "資料新增成功";
	}
require 'base.php';
}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>