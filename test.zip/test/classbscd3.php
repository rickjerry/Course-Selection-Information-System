<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "刪除成功 <br>";
	
	$student_course=$_POST['class1'];
	


    $sqlDelete = "DELETE FROM 科系代碼表
	WHERE 系碼 = ? ";

	$link->query('SET NAMES utf8');
	
	$record=$link->prepare($sqlDelete);	
	$record -> execute(array($student_course));

	require 'base.php';

 

}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>