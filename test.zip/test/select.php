<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<form action="sbform.php" method="get">
<br>
Username: <input type="text" name="username">
Password: <input type="password" name="password">
<br>
<p>功能：輸入學號查詢學生課表</p>
學號：<input type="text" name="student_id">
<br>
<input type="submit">
<br>
<?php include 'base.php'; ?>
</form>
</body>
</html>