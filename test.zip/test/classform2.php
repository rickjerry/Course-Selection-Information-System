<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";#192.168.43.91

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	echo "新增成功 <br>";

	
$student_course=$_POST['class'];
	
$course_name=$_POST['class_name'];
	
$department_id=$_POST['department'];


	$sql = "INSERT INTO 科系代碼表 VALUES (?, ?, ?)";
	$link->query('SET NAMES utf8');
	
$record=$link->prepare($sql);	
$record -> execute(array($student_course,$course_name,$department_id));
	
 

	echo "<br>" . "資料新增成功";

	require 'base.php';
}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>