<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


	$student_id=$_POST['student_id2'];
	$student_name=$_POST['student_name2'];
	$department_id=$_POST["department_id2"];
	
    $sql = "UPDATE 學生資料表 SET 姓名 = ?, 系碼 = ? WHERE 學號 = ?";

	$link->query('SET NAMES utf8');
	
	$record=$link->prepare($sql);	
	$record -> execute(array($student_name,$department_id,$student_id,));
	if($result=$record->rowCount() > 0){
    echo "<br>" . "資料修改成功";
	}
	else{
		echo "<br>" . "沒有這筆資料";
	}	
	require 'base.php';

 

}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>
