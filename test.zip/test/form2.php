<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<form method="post">
<br>
Username: <input type="text" name="username">
Password: <input type="password" name="password">
<br>
<p>功能：新增課程的資料</p>
課號：<input type="text" name="student_course">
課名：<input type="text" name="course_name">
學分數：<input type="text" name="credit">
教師名:<input type="text" name="teacher_name">
<br>
<input type="submit" value="新增" formaction="bform2.php">
<br>

<p>功能：刪除課程的資料</p>
課號：<input type="text" name="student_course1">

<br>
<input type="submit" value="刪除" formaction="bscd3.php">
<br>
<p>功能：修改課程的資料</p>
    課號：<input type="text" name="update_course">
    新課名：<input type="text" name="new_course_name">
    新學分數：<input type="text" name="new_credit">
    新教師名:<input type="text" name="new_teacher_name">
    <br>
    <input type="submit" value="修改" formaction="bupdate.php">
    <br>

    <p>功能：查詢課程的資料</p>
    課號：<input type="text" name="query_course">
    <br>
    <input type="submit" value="查詢" formaction="bquery.php">
    <br>
<?php include 'base.php'; ?>
</form>
</body>
</html>