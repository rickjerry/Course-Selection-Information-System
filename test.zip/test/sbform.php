<html>
<head>
	<title>Hello World PHP.</title>
	<style>

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid black;
            padding: 8px 12px;
            text-align: center;
        }

        table th {
            background-color: #f0e68c;
            color: black;
        }

        table tr:nth-child(even) {
            background-color: #fafad2;
        }
    </style>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_GET['username'],$_GET['password']);


	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


	
$student_id=$_GET['student_id'];
$sql = "SELECT *
FROM 學生資料表
INNER JOIN 選課紀錄表 ON 選課紀錄表.學號 = 學生資料表.學號
INNER JOIN 課程資料表 ON 選課紀錄表.課號 = 課程資料表.課號
WHERE 學生資料表.學號 = ?";


$link->query('SET NAMES utf8');
	
$record=$link->prepare($sql);	
$record -> execute(array($student_id));	
#print_r($result);

	if( $result=$record->fetchAll(PDO::FETCH_ASSOC) ) {
		echo "<br>";
		echo "資料筆數：". $record->rowCount() ."筆<br>";
		echo "<table border='1'>";
		echo "<td>" ."學號:". $result[0]['學號'] . "</td>";
		echo "<td>" ."姓名:". $result[0]['姓名'] . "</td>";
		echo "<td>" ."系碼:". $result[0]['系碼'] . "</td>";
		echo "</table>";
				
		echo "<table border='1'>";
		echo "<tr><th>課號</th><th>課名</th></tr>";
		for ($i = 0; $i < $record->rowCount(); $i++) {
			
		echo "<td>" . $result[$i]['課號'] . "</td>";
		echo "<td>" . $result[$i]['課名'] . "</td>";
		echo "</tr>";  // 結束這一行
		echo "<br>";   // 在每次迴圈結束後換行

}
	
		
	}	
	else{
		echo "沒有選課紀錄 <br>";
	}	        
	echo "</table>";
	require 'base.php';
}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>