<html>
<head>
	<title>Hello World PHP.</title>
	<style>

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid black;
            padding: 8px 12px;
            text-align: center;
        }

        table th {
            background-color: #f0e68c;
            color: black;
        }

        table tr:nth-child(even) {
            background-color: #fafad2;
        }
    </style>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


	
	$student_id=$_POST['student_id3'];
	
	
    $sql = "SELECT * FROM 學生資料表 WHERE 學號 = ?";

	$link->query('SET NAMES utf8');
	
	$record=$link->prepare($sql);	
	$record -> execute(array($student_id,));
	echo "<br>";
	echo "查詢結果：";
	echo "<table border='1'>";
	echo "<tr><th>學號</th><th>姓名</th><th>系所代碼</th></tr>";
	foreach ($record as $id){
		
            echo "<td>". $id['學號']."</td>";
            echo "<td>". $id['姓名']."</td>"; 
            echo "<td>". $id['系碼']."</td>"; 
			echo "</tr>";
	}
	echo "</table>";
	echo "<br>";	
	require 'base.php';

 

}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>