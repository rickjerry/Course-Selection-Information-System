<html>
<head>
	<title>Hello World PHP.</title>
<link rel="stylesheet" href="http://127.0.0.1/test/navbar.css">
</head>
<body>

<div class="navbar">
<a href="<?php echo "http://127.0.0.1/test/form2.php"; ?>">新增課程</a>
<a href="<?php echo "http://127.0.0.1/test/class.php"; ?>">新增科系</a>
<a href="<?php echo "http://127.0.0.1/test/form.php"; ?>">新增學生</a>


<a href="<?php echo "http://127.0.0.1/test/select.php"; ?>">查詢課表</a>
<a href="<?php echo "http://127.0.0.1/test/sc.php"; ?>">加選,退選課程</a>
</div>
</body>
</html>