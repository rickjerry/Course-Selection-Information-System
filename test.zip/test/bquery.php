<?php
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
    $link = new PDO($dsn, $_POST['username'], $_POST['password']);

    $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $query_course = $_POST['query_course'];

    $sqlQuery = "SELECT * FROM 課程資料表 WHERE 課號 = ?";

    $link->query('SET NAMES utf8');

    $record = $link->prepare($sqlQuery);
    $record->execute(array($query_course));

    $result = $record->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo "<br>" . "查詢結果：<br>";
        echo "課號: " . $result['課號'] . "<br>";
        echo "課名: " . $result['課名'] . "<br>";
        echo "學分數: " . $result['學分數'] . "<br>";
        echo "教師名: " . $result['教師'] . "<br>";
    } else {
        echo "<br>" . "查詢結果：找不到相應的課程";
    }
	echo "<br>";
    require 'base.php';
} catch (PDOException $e) {
    echo "連線失敗：" . $e->getMessage();
}

$link = null;
?>
