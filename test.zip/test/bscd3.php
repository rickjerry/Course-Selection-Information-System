<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
	$link = new PDO($dsn,$_POST['username'],$_POST['password']);
 

	$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	
	$student_course=$_POST['student_course1'];
	


    $sqlDelete = "DELETE FROM 課程資料表 
	WHERE 課號 = ? ";

	$link->query('SET NAMES utf8');
	
	$record=$link->prepare($sqlDelete);	
	$record -> execute(array($student_course));
	echo "<br>";
	echo "刪除成功";
	require 'base.php';

 

}
catch (PDOException $e) {
	echo "連線失敗：" . $e->getMessage();
}
$link = null;
?>
</body>
</html>