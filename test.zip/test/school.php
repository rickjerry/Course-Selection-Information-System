<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<?php	
$sever = '192.168.43.91';
$username = 'root';
$password = 'yuan1205';
$dbname = 'school';
$port = '3306';

$conn = new mysqli($sever, $username,$password,$dbname, $port);

if ($conn->connect_error) {
}
else{
	echo "連線成功！！！";
}

mysqli_close($conn);
?>
</body>
</html>