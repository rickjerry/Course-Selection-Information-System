<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<form method="post">
<br>
Username: <input type="text" name="username">
Password: <input type="password" name="password">
<br>
<p>功能：新增單一位學生的學籍資料</p>
學號：<input type="text" name="student_id">
姓名：<input type="text" name="student_name">
系碼：<input type="text" name="department_id">
<br>

<input type="submit" value="新增" formaction="bform.php">
<br>

<p>功能：刪除單一位學生的學籍資料</p>
學號：<input type="text" name="student_id1">

<br>
<input type="submit" value="刪除" formaction="bfd.php">

<p>功能：修改單一位學生的學籍資料</p>
學號：<input type="text" name="student_id2">
姓名：<input type="text" name="student_name2">
系碼：<input type="text" name="department_id2">
<br>
<input type="submit" value="修改" formaction="bc.php">

<p>功能：查詢單一位學生的學籍資料</p>
學號：<input type="text" name="student_id3">

<br>
<input type="submit" value="查詢" formaction="bsf.php">
<br>
<?php include 'base.php'; ?>


</form>
</body>
</html>
