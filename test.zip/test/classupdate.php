<?php
$dsn = "mysql:dbname=school;host=127.0.0.1;port=3306";

try {
    $link = new PDO($dsn, $_POST['username'], $_POST['password']);

    $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $update_course = $_POST['update_class'];
    $new_course_name = $_POST['class_name1'];
    $new_credit = $_POST['department1'];


    $sqlUpdate = "UPDATE 科系代碼表 
                  SET 系名 = ?, 系主任 = ? 
                  WHERE 系碼 = ?";

    $link->query('SET NAMES utf8');

    $record = $link->prepare($sqlUpdate);
    $record->execute(array($new_course_name, $new_credit, $update_course));

    if($result=$record->rowCount() > 0){
    echo "<br>" . "資料修改成功";
	}
	else{
		echo "<br>" . "沒有這筆資料";
	}

    require 'base.php';
} catch (PDOException $e) {
    echo "連線失敗：" . $e->getMessage();
}

$link = null;
?>
