<html>
<head>
	<title>Hello World PHP.</title>
</head>
<body>
<form method="post">
<br>
Username: <input type="text" name="username">
Password: <input type="password" name="password">
<br>
<p>功能：新增科系</p>
系碼：<input type="text" name="class">
系名：<input type="text" name="class_name">
系主任：<input type="text" name="department">
<br>
<input type="submit" value="新增" formaction="classform2.php">
<br>

<p>功能：刪除科系</p>
課號：<input type="text" name="class1">

<br>
<input type="submit" value="刪除" formaction="classbscd3.php">
<br>
<p>功能：修改科系</p>
    系碼：<input type="text" name="update_class">
	系名：<input type="text" name="class_name1">
	系主任：<input type="text" name="department1">
    <br>
    <input type="submit" value="修改" formaction="classupdate.php">
    <br>

    <p>功能：查詢科系</p>
    系碼：<input type="text" name="query_class">
    <br>
    <input type="submit" value="查詢" formaction="classbquery.php">
    <br>
<?php include 'base.php'; ?>
</form>
</body>
</html>